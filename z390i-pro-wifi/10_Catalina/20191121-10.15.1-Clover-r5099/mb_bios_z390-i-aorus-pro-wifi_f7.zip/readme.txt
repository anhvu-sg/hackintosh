Usage :
	efiflash [Input or Output File Name] [Command]..

   Switch options for Efiflash.exe:
    /C - Clear DMI data. (default: Keep DMI data)
    /S - Save Original BIOS Image to Disk
    /R - Reboot System after BIOS Update
    /DB- Update both main & backup BIOS


